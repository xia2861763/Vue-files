# 用vue开发购物车

> 功能：用vue简单实现购物车增删减少商品以及价格，地址的增加删除。

>  [项目体验链接](https://jgchenu.github.io/vue-shopcar/)

> [该源码教程视频](http://www.imooc.com/learn/796)
